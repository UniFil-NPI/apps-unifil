---
title: "SimpleJourney"
important: 4
draft: false
language: pt-br
summary: Projeto dedicado para compartilhar experiencias relacionadas ao aprendizado dentro da área de programação.
author: Matheus Kenzo, Rafael Favoreto, Vitor Yuuki, Mendjy Eliaza
featured_image: images/featured/simpleJourney.jpg
categories: Blog
tags: ["CC", "ES"] 
linkweb: http://168.138.150.72/
linkblog: https://portextensao.blogspot.com/
linkvideo: https://youtu.be/b2NSdI5kO2o

---
---


# SimpleJourney
Um pequeno site que tem como intuito compartilhar as experiencias e lições aprendias durante o nosso trajeto na jornada do estudo da programação.
O site e separado por artigos escritos por nos, membros do SimpleJourney, tais artigos abordam conhecimentos, dicas e fontes que achamos de grande importância compartilhar com os outros, principalmente com os novatos da area!

 